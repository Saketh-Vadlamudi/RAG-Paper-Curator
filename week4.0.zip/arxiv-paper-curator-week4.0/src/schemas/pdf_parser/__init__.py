# PDF Parser service schemas
