# ArXiv service schemas
